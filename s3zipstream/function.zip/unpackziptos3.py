import logging
import os
from http import HTTPStatus
import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    try:
        logger.info(f'Calling out to ')

        logger.info('Event: %s', event)

    except Exception as e:
        logger.error(e, exe_info=True)
        raise Exception('Error occured during unpackziptoS3')
    
    return {
        "statusCode": HTTPStatus.OK.value
    }
